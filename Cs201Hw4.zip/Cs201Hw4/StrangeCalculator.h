/*
 * @author Efe Kerem Kesgin 21902857
 * @date 11.05.2021
 */

#ifndef CS201HW4_STRANGECALCULATOR_H
#define CS201HW4_STRANGECALCULATOR_H

#include <iostream>
using namespace std;

string infix2prefix( const string reverse );
double evaluatePrefix( const string exp );
bool isBalancedInfix( const string exp );
void evaluateInputPrefixExpression();
int priority(char exp);

class StrangeCalculator {

};


#endif //CS201HW4_STRANGECALCULATOR_H

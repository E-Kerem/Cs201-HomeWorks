/*
 * @author Efe Kerem Kesgin 21902857
 * @date 11.05.2021
 */

#include "StrangeCalculator.h"
#include "Stack.h"
#include "Stack.cpp" //for the linking template usage
#include <iostream>

using namespace std;


string infix2prefix(const string exp) {
    string reverse = "";
    for (int i = exp.length() - 1; i >= 0; --i) {
        if (exp.at(i) == '(')
            reverse += ')';
        else if (exp.at(i) == ')')
            reverse += '(';
        else
            reverse += exp.at(i);
    }
    typedef Stack<char> CharStack;
    CharStack aStack;

    string result, result2;
    char tmpChar, topItem;

    for (int i = 0; i < reverse.length(); ++i) {
        tmpChar = reverse.at(i);
        topItem = ' ';
        aStack.getTop(topItem);
        if (isdigit(tmpChar)) //since "operands are single-digit numbers".
            result += tmpChar;
        else if (tmpChar == '(')
            aStack.push(tmpChar);
        else if (tmpChar == ')') {
            while (topItem != '(' && !aStack.isEmpty() ) {
                aStack.pop(topItem);
                result += topItem;
                if (!aStack.getTop(topItem))
                    topItem = ' ';
            }
            if ( topItem == '(' ) {
                aStack.pop();
            }
        } else if (tmpChar == '/' || tmpChar == '*' || tmpChar == '+' || tmpChar == '-') {
            while (!(aStack.isEmpty()) && topItem != '(' && (priority(tmpChar) < priority(topItem))) {
                aStack.pop(topItem);
                result += topItem;
                if ( !aStack.getTop(topItem) )
                    topItem = ' ';
            }
            aStack.push(tmpChar);
        }
    }
    while ( !aStack.isEmpty() ) {
        aStack.getTop(topItem);
        result += topItem;
        aStack.pop();
    }
    for (int i = result.length() - 1; i >= 0; --i) {
        result2 += result.at(i);
    }
    return result2;
}

double evaluatePrefix(const string exp) {

    typedef Stack<double> DoubleStack;
    DoubleStack dStack;

    double result;
    for (int i = exp.length() - 1; i >= 0; --i) {
        if (isdigit(exp.at(i)))
            dStack.push(exp.at(i) - '0');
        else {
            double top1, top2;
            dStack.getTop(top1);
            dStack.pop();
            dStack.getTop(top2);
            dStack.pop();
            switch (exp.at(i)) {
                case '+':
                    dStack.push((top1 + top2));
                    break;
                case '-':
                    dStack.push((top1 - top2));
                    break;
                case '*':
                    dStack.push((top1 * top2));
                    break;
                case '/':
                    dStack.push((top1 / top2));
                    break;
            }
        }
    }
    dStack.getTop(result);
    return result;
}

int priority(char exp) {
    if (exp == '+' || exp == '-') return 1;
    if (exp == '*' || exp == '/') return 2;
    return 0;
}

bool isBalancedInfix(const string exp) {
    typedef Stack<char> CharStack2;
    CharStack2 cStack;

    int i = 0;
    char tmp;
    bool balancedSoFar = true;

    while (balancedSoFar && i < exp.length()) {
        tmp = exp.at(i);
        ++i;
        if (tmp == ' ')
            continue;
        else if (tmp == '(')
            cStack.push(')');
        else if (tmp == ')') {
            if (!(cStack.isEmpty()))
                cStack.pop();
            else
                balancedSoFar = false;
        }
    }
    if (balancedSoFar && cStack.isEmpty())
        return true;
    else
        return false;
}

void evaluateInputPrefixExpression() {
    string tmpStr;
    string result = "";
    cout << "Please give an infix input: ";
    getline(cin,tmpStr);

    // removes the possible spaces in the input
    for (int i = 0; i < tmpStr.length(); ++i) {
        char tmpC = tmpStr.at(i);
        if (tmpC != ' ')
            result += tmpC;
    }

    if (!isBalancedInfix(result))
        cout << "This is an unbalanced parentheses infix expression" << endl;
    else
        cout << evaluatePrefix(infix2prefix(result)) << endl;
}


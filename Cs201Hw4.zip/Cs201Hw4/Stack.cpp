/*
 * @author Efe Kerem Kesgin 21902857
 * @date 11.05.2021
 */
#include "Stack.h"
template <class T> //For using different type of stacks
Stack<T>::Stack() : topPtr(NULL) {

}
template <class T>
Stack<T>::Stack(const Stack &aStack) {
    if (aStack.topPtr == NULL)
        topPtr = NULL;
    else {
        topPtr = new StackNode;
        topPtr->item = aStack.topPtr->item;
        StackNode *newPtr = topPtr;
        for (StackNode *origPtr = aStack.topPtr->next;
             origPtr != NULL;
             origPtr = origPtr->next) {
            newPtr->next = new StackNode;
            newPtr = newPtr->next;
            newPtr->item = origPtr->item;
        }
        newPtr->next = NULL;
    }
}
template <class T>
Stack<T>::~Stack() {
    while (!isEmpty())
        pop();
}
template <class T>
bool Stack<T>::isEmpty() const {
    return topPtr == NULL;
}
template <class T>
bool Stack<T>::push(T newItem) {
    StackNode *newPtr = new StackNode;
    newPtr->item = newItem;
    newPtr->next = topPtr;
    topPtr = newPtr;
    return true;
}
template <class T>
bool Stack<T>::pop() {
    if (isEmpty())
        return false;
    else {
        StackNode *temp = topPtr;
        topPtr = topPtr->next;
        temp->next = NULL;
        delete temp;
        return true;
    }
}
template <class T>
bool Stack<T>::pop(T &stackTop) {
    if (isEmpty())
        return false;
    else {
        stackTop = topPtr->item;
        StackNode *temp = topPtr;
        topPtr = topPtr->next;
        temp->next = NULL;
        delete temp;
        return true;
    }
}
template <class T>
bool Stack<T>::getTop(T &stackTop) const {
    if (isEmpty())
        return false;
    else {
        stackTop = topPtr->item;
        return true;
    }
}

/*
 * @author Efe Kerem Kesgin 21902857
 * @date 11.05.2021
 */
#ifndef CS201HW4_STACK_H
#define CS201HW4_STACK_H

#include <iostream>
using namespace std;

template <class T>
//typedef char StackItemType;

class Stack{

public:
    Stack();
    Stack(const Stack& aStack);
    ~Stack();

    bool isEmpty() const;
    bool push(T newItem);
    bool pop();
    bool pop(T& stackTop);
    bool getTop(T& stackTop) const;

private:
    struct StackNode {            // a node on the stack
        T item;        // stack's data item
        StackNode    *next;        // next node pointer
    };

    StackNode *topPtr;     // pointer to first node in the stack
};

#endif //CS201HW4_STACK_H

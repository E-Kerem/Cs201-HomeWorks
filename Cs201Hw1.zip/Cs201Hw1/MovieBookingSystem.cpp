/*
 * @author Efe Kerem Kesgin 21902857
 * @date 17.03.2021.
 */

#include "MovieBookingSystem.h"
#include "Movie.h"
#include "Reservation.h"
#include <iostream>

using namespace std;

MovieBookingSystem::MovieBookingSystem() {
    this->movieCounter = 0;
    this->reservationCounter = 0;
    this->reservationNumber = 1;
}

MovieBookingSystem::~MovieBookingSystem() {
    for (int i = 0; i < this->movieCounter; ++i) {
        delete this->movies[i];
    }
    delete[] this->movies;

    for (int i = 0; i < this->reservationCounter; ++i) {
        delete this->reservations[i];
    }
    delete[] this->reservations;
}

void MovieBookingSystem::addMovie(const long movieID, const int audienceRadius) {
    for (int i = 0; i < this->movieCounter; ++i) {
        if (this->movies[i]->getMovieId() == movieID) {
            cout << "Movie at " << this->movies[i]->getTime() << " already exist" << endl;
            return;
        }
    }
    Movie *m = new Movie(movieID, audienceRadius);
    Movie **temp = new Movie *[this->movieCounter + 1];
    for (int i = 0; i < this->movieCounter; ++i) {
        temp[i] = this->movies[i];
    }
    temp[this->movieCounter] = m;

    if (this->movieCounter > 0)
        delete[] this->movies;
    this->movies = temp;
    cout << "Movie at " << m->getTime() << " has been added" << endl;
    this->movieCounter++;
}

void MovieBookingSystem::showMovie(const long movieID) {
    int radious = 0;
    for (int i = 0; i < movieCounter; ++i) {
        if (this->movies[i]->getMovieId() == movieID) {
            radious = this->movies[i]->getAudienceRadius();
            int fullSeatNumber = (1 + (numOfRow - 1) / (radious + 1)) * (1 + (numOfColumn - 1) / (radious + 1));
            int resSeats = 0;
            for (int j = 0; j < this->reservationCounter; ++j) {
                if (this->reservations[j]->getMovieId() == this->movies[i]->getMovieId()) {
                    resSeats++;
                }
            }
            cout << "Movie at " << this->movies[i]->getTime() << " " << fullSeatNumber - resSeats << " available seats"
                 << endl;
            break;
        }
    }
    cout << "  ";
    for (char i = 'A'; i <= 'Z'; i = i + radious + 1) {
        cout << "  " << i;
    }
    for (int j = 1; j <= numOfRow; j = j + radious + 1) {
        if (j < 10) {
            cout << "\n" << " " << j;
        } else {
            cout << "\n" << j;
        }
        for (char i = 'A'; i <= 'Z'; i = i + radious + 1) {
            bool doesExist = false;
            for (int k = 0; k < this->reservationCounter; ++k) {
                if (this->reservations[k]->getMovieId() == movieID && this->reservations[k]->getRow() == j &&
                    this->reservations[k]->getCol() == i) {
                    doesExist = true;
                    k = this->reservationCounter;
                }
            }
            if (doesExist)
                cout << "  x";
            else
                cout << "  o";
        }
    }
    cout << endl;
}

void MovieBookingSystem::cancelMovie(const long movieID) {
    bool doesExist = false;
    for (int i = 0; i < this->movieCounter; ++i) {
        doesExist = this->movies[i]->getMovieId() == movieID;
        if (doesExist) {
            cout << "Movie at " << this->movies[i]->getTime() << " has been canceled" << endl;
            break;
        }
    }
    if (!doesExist) {
        time_t *currTime = new time_t(movieID);
        std::string date = ctime(currTime);
        delete currTime;
        date = date.substr(0, date.length() - 1);
        cout << "Movie at " << date << " does not exist" << endl;
        return;
    }
    int tempIndex = 0;
    Movie **tempArr = new Movie *[this->movieCounter - 1];
    for (int i = 0; i < this->movieCounter; ++i) {
        if (this->movies[i]->getMovieId() == movieID) {
            delete this->movies[i];
        } else {
            tempArr[tempIndex++] = this->movies[i];
        }
    }
    delete[] this->movies;
    this->movies = tempArr;
    this->movieCounter--;

    int delResCount = 0;
    for (int i = 0; i < this->reservationCounter; ++i) {
        if (this->reservations[i]->getMovieId() == movieID) {
            delResCount++;
        }
    }
    if (delResCount == 0) {
        return;
    }

    Reservation **temp = new Reservation *[this->reservationCounter - delResCount];
    tempIndex = 0;
    for (int i = 0; i < this->reservationCounter; ++i) {
        if (this->reservations[i]->getMovieId() == movieID) {
            delete this->reservations[i];
        } else {
            temp[tempIndex++] = this->reservations[i];
        }
    }
    delete[] reservations;
    this->reservationCounter -= delResCount;
    this->reservations = temp;
}

void MovieBookingSystem::showAllMovies() {
    int count = 0;
    int x = 0;
    if (this->movieCounter == 0) {
        cout << "No movie on show" << endl;
        return;
    }
    cout << "Movies on show:" << endl;
    for (int i = 0; i < this->movieCounter; ++i) {
        x = (1 + (numOfRow - 1) / (movies[i]->getAudienceRadius() + 1)) *
            (1 + (numOfColumn - 1) / (movies[i]->getAudienceRadius() + 1));
        for (int j = 0; j < this->reservationCounter; ++j) {
            if (this->reservations[j]->getMovieId() == this->movies[i]->getMovieId()) {
                count++;
            }
        }
        cout << "Movie at " << movies[i]->getTime() << "(" << x - count << " available seats)" << endl;
        count = 0;
        x = 0;
    }
}

int MovieBookingSystem::makeReservation(const long movieID, const int row, const char col) {
    for (int i = 0; i < this->reservationCounter; ++i) {
        if (this->reservations[i]->getMovieId() == movieID &&
            this->reservations[i]->getCol() == col &&
            this->reservations[i]->getRow() == row) {
            cout << "Seat " << this->reservations[i]->getCol() << this->reservations[i]->getRow();
            cout << " is not available in Movie at " << this->reservations[i]->getTimeRes() << endl;
            return -1;
        }
    }
    for (int i = 0; i < this->movieCounter; ++i) {
        if (this->movies[i]->getMovieId() == movieID) {
            int r = this->movies[i]->getAudienceRadius();
            if ((row - 1) % (r + 1) != 0 || (col - 1) % (r + 1) != 0) {
                cout << "Seat " << col << row << " is not occupiable in Movie at ";
                cout << this->reservations[i]->getTimeRes() << endl;
                return -1;
            }
        }
    }
    Reservation *r = new Reservation(movieID, row, col, this->reservationNumber++);
    Reservation **temp = new Reservation *[this->reservationCounter + 1];
    for (int i = 0; i < this->reservationCounter; ++i) {
        temp[i] = this->reservations[i];
    }
    temp[this->reservationCounter] = r;
    if (this->reservationCounter > 0)
        delete[] this->reservations;
    this->reservations = temp;
    this->reservationCounter++;

    cout << "Reservation done for " << r->getCol();
    cout << r->getRow();
    cout << " in Movie at " << r->getTimeRes() << endl;
    return r->getId();
}

void MovieBookingSystem::cancelReservations(const int numRes, const int *resCode) {
    int count = 0;
    for (int i = 0; i < numRes; ++i) {
        for (int j = 0; j < this->reservationCounter; ++j) {
            if (this->reservations[j]->getId() == resCode[i]) {
                count++;
                break;
            }
        }
    }
    if (count != numRes) {
        cout << "Some reservation codes do not exist. Cancelation is failed" << endl;
        return;
    } else {
        for (int i = 0; i < numRes; ++i) {
            for (int j = 0; j < this->reservationCounter; ++j) {
                if (this->reservations[j]->getId() == resCode[i]) {
                    cout << "Reservation on Code " << this->reservations[j]->getId() << " is canceled: ";
                    cout << " Seat " << this->reservations[j]->getCol() << this->reservations[j]->getRow();
                    cout << " in Movie at " << this->reservations[j]->getTimeRes() << endl;
                }
            }
        }

        Reservation **nReservations = NULL;
        int newResCount = this->reservationCounter - count;
        if (newResCount > 0) {
            nReservations = new Reservation *[this->reservationCounter - count];
        }
        for (int i = 0; i < this->reservationCounter; ++i) {
            bool isExist = false;
            for (int j = 0; j < numRes; ++j) {
                isExist = this->reservations[i]->getId() == resCode[j];
                if (isExist) {
                    delete this->reservations[i];
                    break;
                }
            }
            if (!isExist && nReservations != NULL) {
                nReservations[i] = this->reservations[i];
            }
        }
        delete[] reservations;
        this->reservationCounter -= count;
        this->reservations = nReservations;
    }
}

void MovieBookingSystem::showReservation(const int resCode) {
    bool exist = false;
    for (int i = 0; i < this->reservationCounter; ++i) {
        if (this->reservations[i]->getId() == resCode) {
            cout << "Reservation with Code " << this->reservations[i]->getId() << ": Seat "
                 << this->reservations[i]->getCol()
                 << this->reservations[i]->getRow() << " in Movie at " << this->reservations[i]->getTimeRes() << endl;
            exist = true;
        }
    }
    if (!exist) {
        cout << "No reservation with Code " << resCode << endl;
    }
}

/*
 * @author Efe Kerem Kesgin 21902857
 * @date 17.03.2021.
 */

#include "Reservation.h"
#include <ctime>

Reservation::Reservation(long movieID, int row, char col, int id) {
    this->movieID = movieID;
    this->row = row;
    this->col = col;
    this->id = id;
}

Reservation::~Reservation() {
    //cout << "Reservation ID " << this->id << " deleted";
}

int Reservation::getId() const {
    return id;
}

long Reservation::getMovieId() const {
    return movieID;
}

int Reservation::getRow() const {
    return row;
}

char Reservation::getCol() const {
    return col;
}

string Reservation::getTimeRes() const {
    time_t *currTime = new time_t(getMovieId());
    std::string date = ctime(currTime);
    delete currTime;
    date = date.substr(0, date.length() - 1);
    return date;
}

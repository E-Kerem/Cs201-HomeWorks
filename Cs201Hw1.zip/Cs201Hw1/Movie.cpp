/*
 * @author Efe Kerem Kesgin 21902857
 * @date 17.03.2021.
 */

#include "Movie.h"
#include <ctime>

Movie::Movie(long movieId, int audienceRadius) {
    this->movieId = movieId;
    this->audienceRadius = audienceRadius;
}

Movie::~Movie() {
    //cout << "Movie ID " << this->movieId << " deleted";
}

long Movie::getMovieId() const {
    return movieId;
}

int Movie::getAudienceRadius() const {
    return audienceRadius;

}

string Movie::getTime() const {
    time_t *currTime = new time_t(movieId);
    std::string date = ctime(currTime);
    delete currTime;
    date = date.substr(0, date.length() - 1);
    return date;
}

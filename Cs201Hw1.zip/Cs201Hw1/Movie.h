/*
 * @author Efe Kerem Kesgin 21902857
 * @date 17.03.2021.
 */
#ifndef CS201_HW1_MOVIE_H
#define CS201_HW1_MOVIE_H

#include <string>
#include <iostream>

using namespace std;

class Movie {
public:
    Movie(long movieId, int audienceRadius);

    ~Movie();

    long getMovieId() const;

    int getAudienceRadius() const;

    string getTime() const;

private:
    string timeMovie;
    long movieId;
    int audienceRadius;
};

#endif //CS201_HW1_MOVIE_H

/*
 * @author Efe Kerem Kesgin 21902857
 * @date 17.03.2021.
 */

#ifndef CS201_HW1_RESERVATION_H
#define CS201_HW1_RESERVATION_H

#include <string>
#include <iostream>

using namespace std;

class Reservation {
public:
    Reservation(const long movieID, const int row, const char col, int id);

    ~Reservation();

    int getId() const;

    long getMovieId() const;

    int getRow() const;

    char getCol() const;

    string getTimeRes() const;

private:
    string timeRes;
    long movieID;
    int row;
    char col;
    int id;
};

#endif //CS201_HW1_RESERVATION_H

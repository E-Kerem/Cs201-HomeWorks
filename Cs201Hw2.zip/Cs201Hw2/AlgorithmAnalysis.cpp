/*
 *@author Efe Kerem Kesgin 21902857
 *@date 3.04.2021.
 */

#include "AlgorithmAnalysis.h"

int AlgorithmAnalysis::iterativeLinearSearch(int *arr, int arrSize, int key) {
    for (int i = 0; i < arrSize; i++)
        if (arr[i] == key)
            return i;
    return -1;
}

int AlgorithmAnalysis::recursiveLinearSearch(int *arr, int arrSize, int key) {
    arrSize--;
    if (arrSize < 0) {
        return -1;
    } else if (arr[arrSize] == key) {
        return arrSize;
    } else {
        return recursiveLinearSearch(arr, arrSize, key);
    }
}

int AlgorithmAnalysis::binarySearch(int* arr, int low, int high, int key){
    if( low > high)
        return -1;
    int mid = (low+high)/2;
    if(arr[mid] == key)
        return mid;
    if(arr[mid] < key)
        return binarySearch(arr, mid+1, high, key);
    return binarySearch(arr, low, mid-1, key);
}

int AlgorithmAnalysis::jumpSearch(int *arr, int arrSize, int key) {
    int step = sqrt(arrSize);
    int prev = 0;
    while (arr[min(step, arrSize) - 1] < key) {
        prev = step;
        step += sqrt(arrSize);
        if (prev >= arrSize)
            return -1;
    }
    while (arr[prev] < key) {
        prev++;
        if (prev == min(step, key))
            return -1;
    }
    if (arr[prev] == key)
        return prev;
    return -1;
}

int *AlgorithmAnalysis::createRandomArr(const int arrSize) {
    int const range = 10 * arrSize;
    int *arr = new int[arrSize];
    for (int i = 0; i < arrSize; i++)
        arr[i] = rand() % range;  //Generate number between 0 to range
    return arr;
}
void heapify(int *arr, int n, int i) {
    int temp;
    int largest = i;
    int l = 2 * i + 1;
    int r = 2 * i + 2;
    if (l < n && arr[l] > arr[largest])
        largest = l;
    if (r < n && arr[r] > arr[largest])
        largest = r;
    if (largest != i) {
        temp = arr[i];
        arr[i] = arr[largest];
        arr[largest] = temp;
        heapify(arr, n, largest);
    }
}
void heapSort(int *arr, int n) {
    int temp;
    for (int i = n / 2 - 1; i >= 0; i--)
        heapify(arr, n, i);
    for (int i = n - 1; i >= 0; i--) {
        temp = arr[0];
        arr[0] = arr[i];
        arr[i] = temp;
        heapify(arr, i, 0);
    }
}

void printArray(int arr[], int n) {
    for (int i = 0; i < n; ++i)
        cout << arr[i] << " ";
    cout << "\n";
}

int main() {
    AlgorithmAnalysis a;
    int const runTime = 100000;

    int sizes[10];
    sizes[0] = 100; // First N

    for (int i = 1; i < 10; ++i) {
        if ( i <= 2 )
            sizes[i] = sizes[i - 1] * 5;
        if (  i > 2 && i <= 7)
            sizes[i] = sizes[i - 1] * 2;
        if ( i > 7 && i < 10 )
            sizes[i] = sizes[i - 1] + 10000;
    }

    for (int i = 0; i < 10; ++i) {
        cout << "Size" <<" " << sizes[i] << endl;
    }

    int *arr1 = a.createRandomArr(sizes[0]);
    int *arr2 = a.createRandomArr(sizes[1]);
    int *arr3 = a.createRandomArr(sizes[2]);
    int *arr4 = a.createRandomArr(sizes[3]);
    int *arr5 = a.createRandomArr(sizes[4]);
    int *arr6 = a.createRandomArr(sizes[5]);
    int *arr7 = a.createRandomArr(sizes[6]);
    int *arr8 = a.createRandomArr(sizes[7]);
    int *arr9 = a.createRandomArr(sizes[8]);
    int *arr10 = a.createRandomArr(sizes[9]);

    int **arrays = new int *[10];
    arrays[0] = arr1;
    arrays[1] = arr2;
    arrays[2] = arr3;
    arrays[3] = arr4;
    arrays[4] = arr5;
    arrays[5] = arr6;
    arrays[6] = arr7;
    arrays[7] = arr8;
    arrays[8] = arr9;
    arrays[9] = arr10;

    for (int i = 0; i < 10; ++i) {
        heapSort(arrays[i], sizes[i]);
    }

    for (int i = 0; i < 10; ++i) {
        cout << "Iterative Linear Search for arr" << i << ": ";
        double duration;
        clock_t startTime;
        startTime = clock();
        for (int j = 0; j < runTime; ++j) {
            a.iterativeLinearSearch(arrays[i], sizes[i],   arrays[i][ sizes[i] - 2 ]);
        }
        duration = 1000 * double(clock() - startTime) / CLOCKS_PER_SEC;
        duration = (duration / runTime);
        cout << "Execution took " << duration << " milliseconds." << endl;
    }

    cout << endl;
    for (int i = 0; i < 10; ++i) {
        cout << "Recursive Linear Search for arr" << i << ": ";
        double duration;
        clock_t startTime;
        startTime = clock();
        for (int j = 0; j < runTime; ++j) {
            a.recursiveLinearSearch(arrays[i], sizes[i],   arrays[i][ sizes[i] - 2 ]);
        }
        duration = 1000 * double(clock() - startTime) / CLOCKS_PER_SEC;
        duration = duration / runTime;
        cout << "Execution took " << duration << " milliseconds." << endl;
    }
    cout << endl;

    for (int i = 0; i < 10; ++i) {
        cout << "Binary Search for arr" << i << ": ";
        double duration;
        clock_t startTime;
        startTime = clock();
        for (int j = 0; j < runTime; ++j) {
            a.binarySearch(arrays[i], 0,sizes[i],   -1);
        }
        duration = 1000 * double(clock() - startTime) / CLOCKS_PER_SEC;
        duration = duration / runTime;
        cout << "Execution took " << duration << " milliseconds." << endl;
    }
    cout << endl;
    for (int i = 0; i < 10; ++i) {
        cout << "Jump Search for arr" << i << ": ";
        double duration;
        clock_t startTime;
        startTime = clock();
        for (int j = 0; j < runTime; ++j) {
            a.jumpSearch(arrays[i], sizes[i],  arrays[i][ sizes[i] - 2 ] ); // arrays[i][0] for part a -- arrays[i][ sizes[i] / 2 ] for part b -- arrays[i][ sizes[i] - 2 ] for part c
        }
        duration = 1000 * double(clock() - startTime) / CLOCKS_PER_SEC;
        duration = duration / runTime;
        cout << "Execution took " << duration << " milliseconds." << endl;
    }

    for (int i = 0; i < 10; ++i) {
        delete[] arrays[i];
    }
    delete[] arrays;
    return 0;
}

/*
 *@author Efe Kerem Kesgin 21902857
 *@date 3.04.2021.
 */

#ifndef CS201HW2_ALGORITHMANALYSIS_H
#define CS201HW2_ALGORITHMANALYSIS_H

#include <ctime>
#include <iostream>
#include <cmath>
#include <cstdlib>

using namespace std;

class AlgorithmAnalysis {
public:
    int iterativeLinearSearch( int* arr, int arrSize, int key );
    int recursiveLinearSearch(int* arr,int arrSize,int key);
    int binarySearch(int* arr, int low, int high, int key);
    int jumpSearch(int* arr, int arrSize, int key);
    int* createRandomArr(const int arrSize);
};


#endif //CS201HW2_ALGORITHMANALYSIS_H

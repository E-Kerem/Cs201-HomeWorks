/*
 * @author Efe Kerem Kesgin 21902857
 * @date 03.05.2021.
 */

#include "MovieBookingSystem.h"
#include "Reservation.h"
#include <iostream>

using namespace std;

MovieBookingSystem::MovieBookingSystem() : reservationNumber(1), reservationCounter(0) {
    //this->movieCounter = 0; this->reservationCounter = 0; this->reservationNumber = 1;
}

MovieBookingSystem::~MovieBookingSystem() {
}

void MovieBookingSystem::addMovie(const long movieID, const int audienceRadius) {
    bool isExist = movies.find(movieID, audienceRadius);
    if (isExist) {
        cout << "Movie at " << movies.getTime(movieID) << " already exists" << endl;
        return;
    }
    movies.insert(1, movieID, audienceRadius);
    cout << "Movie at " << movies.getTime(movieID) << " has been added" << endl;
}

void MovieBookingSystem::showMovie(const long movieID) const {
    int radious = 0;
    for (int i = 1; i <= movies.getLength(); ++i) {
        long tmpId;
        int tmpRad;
        movies.retrieve(i, tmpId, tmpRad);
        radious = tmpRad;
        if (tmpId == movieID) {
            int fullSeatNumber = (1 + (numOfRow - 1) / (tmpRad + 1)) * (1 + (numOfColumn - 1) / (tmpRad + 1));
            int resSeats = 0;
            Reservation tmpReservation;
            for (int j = 1; j <= this->reservationCounter; ++j) {
                reservationCodes.retrieve(j, tmpReservation);
                if (tmpReservation.getMovieId() == movieID) {
                    resSeats++;
                }
            }
            cout << "Movie at " << movies.getTime(movieID) << " " << fullSeatNumber - resSeats << " available seats"
                 << endl;
            break;
        }
    }
    cout << "  ";
    for (char i = 'A'; i <= 'Z'; i = i + radious + 1) {
        cout << "  " << i;
    }
    for (int j = 1; j <= numOfRow; j = j + radious + 1) {
        if (j < 10) {
            cout << "\n" << " " << j;
        } else {
            cout << "\n" << j;
        }
        for (char i = 'A'; i <= 'Z'; i = i + radious + 1) {
            bool doesExist = false;
            for (int k = 1; k <= this->reservationCounter; ++k) {
                Reservation tmpReservation;
                reservationCodes.retrieve(k, tmpReservation);
                if (tmpReservation.getMovieId() == movieID && tmpReservation.getRow() == j &&
                    tmpReservation.getCol() == i) {
                    doesExist = true;
                    k = this->reservationCounter;
                }
            }
            if (doesExist)
                cout << "  x";
            else
                cout << "  o";
        }
    }
    cout << endl;
}

void MovieBookingSystem::cancelMovie(const long movieID) {
    bool doesExist = false;
    long tmpId;
    int tmpRad;
    for (int i = 0; i < movies.getLength(); ++i) {
        movies.retrieve(i, tmpId, tmpRad);
        if (tmpId == movieID) {
            cout << "Movie at " << movies.getTime(movieID) << " has been canceled" << endl;
            doesExist = true;
            movies.remove(i);

            ReservationList deleteList;
            Reservation tmpRes;
            for (int i = 1; i <= reservationCodes.getLength(); ++i) {
                reservationCodes.retrieve(i, tmpRes);
                if (tmpRes.getMovieId() == movieID) {
                    deleteList.insert(0, tmpRes.getId());
                }
            }
            for (int i = 1; i <= deleteList.getLength(); ++i) {
                int resCompareCode;
                int deleteCompareCode;
                deleteList.retrieve(i, resCompareCode);
                for (int j = 1; j <= reservationCodes.getLength(); ++j) {
                    reservationCodes.retrieve(j, deleteCompareCode);
                    if (resCompareCode == deleteCompareCode) {
                        reservationCodes.remove(j);
                        break;
                    }
                }
            }
            break;
        }
    }
    if (!doesExist) {
        cout << "Movie at " << movies.getTime(movieID) << " does not exist" << endl;
        return;
    }
}

void MovieBookingSystem::showAllMovies() const {
    int count = 0;
    int x;
    if (movies.isEmpty()) {
        cout << "No movie on show" << endl;
        return;
    }
    cout << "Movies on show:" << endl;
    for (int i = movies.getLength(); i > 0; --i) {
        long curMovieId;
        int curMovieRad;
        movies.retrieve(i, curMovieId, curMovieRad);
        x = (1 + (numOfRow - 1) / (curMovieRad + 1)) *
            (1 + (numOfColumn - 1) / (curMovieRad + 1));
        for (int j = 1; j <= reservationCodes.getLength(); ++j) {
            Reservation curRes;
            reservationCodes.retrieve(j, curRes);
            if (curRes.getMovieId() == curRes.getMovieId()) {
                count++;
            }
        }
        cout << "Movie at " << movies.getTime(curMovieId) << "(" << x - count << " available seats)" << endl;
    }
}

int MovieBookingSystem::makeReservation(const long movieID, const int row, const char col) {
    Reservation selectedRes;
    for (int i = 1; i <= reservationCodes.getLength(); ++i) {
        reservationCodes.retrieve(i, selectedRes);
        if (selectedRes.getMovieId() == movieID &&
            selectedRes.getCol() == col && selectedRes.getRow() == row) {
            cout << "Seat " << selectedRes.getCol() << selectedRes.getRow();
            cout << " is not available in Movie at " << selectedRes.getTimeRes() << endl;
            return -1;
        }
    }
    for (int i = 1; i <= movies.getLength(); ++i) {
        int resMovieRad;
        long resMovieId;
        movies.retrieve(i, resMovieId, resMovieRad);
        if (resMovieId == movieID) {
            if ((row - 1) % (resMovieRad + 1) != 0 || (col - 1) % (resMovieRad + 1) != 0) {
                cout << "Seat " << col << row << " is not occupiable in Movie at ";
                cout << movies.getTime(resMovieId) << endl;
                return -1;
            }
        }
    }
    this->reservationCounter++;
    Reservation newRes(movieID, row, col, reservationNumber);
    reservationCodes.insert(1, newRes, reservationNumber++);

    cout << "Reservation done for " << newRes.getCol();
    cout << newRes.getRow();
    cout << " in Movie at " << newRes.getTimeRes() << endl;
    return newRes.getId();
}

void MovieBookingSystem::cancelReservations(ReservationList resCode) {
    int count = 0;
    for (int i = 1; i <= resCode.getLength(); ++i) {
        int tmpCode;
        resCode.retrieve(i, tmpCode);
        for (int j = 1; j <= this->reservationCounter; ++j) {
            int realCode;
            reservationCodes.retrieve(j, realCode);
            if (realCode == tmpCode) {
                count++;
                break;
            }
        }
    }
    if (count != resCode.getLength()) {
        cout << "Some reservation codes do not exist. Cancelation is failed" << endl;
        return;
    } else {
        for (int i = 1; i <= resCode.getLength(); ++i) {
            int tmpCode;
            resCode.retrieve(i, tmpCode);
            for (int j = 1; j <= reservationCodes.getLength(); ++j) {
                Reservation curRes;
                int realCode;
                reservationCodes.retrieve(j, realCode);
                reservationCodes.retrieve(j, curRes);
                if (realCode == tmpCode) {
                    cout << "Reservation on Code " << tmpCode << " is canceled: ";
                    cout << " Seat " << curRes.getCol() << curRes.getRow();
                    cout << " in Movie at " << curRes.getTimeRes() << endl;
                    reservationCodes.remove(j);
                    break;
                }
            }
        }
    }
}

void MovieBookingSystem::showReservation(const int resCode) const {
    bool exist = false;
    for (int i = 1; i < reservationCodes.getLength() + 1; ++i) {
        Reservation curRes;
        reservationCodes.retrieve(i, curRes);
        if (curRes.getId() == resCode) {
            cout << "Reservation with Code " << curRes.getId() << ": Seat "
                 << curRes.getCol()
                 << curRes.getRow() << " in Movie at " << curRes.getTimeRes() << endl;
            exist = true;
            break;
        }
    }
    if (!exist) {
        cout << "No reservation with Code " << resCode << endl;
    }
}

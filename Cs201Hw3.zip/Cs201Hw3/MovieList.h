/*
 * @author Efe Kerem Kesgin 21902857
 * @date 03.05.2021.
 */

#ifndef CS201HW3_MOVIELIST_H
#define CS201HW3_MOVIELIST_H

#include <iostream>

using namespace std;

class MovieList {
public:
    MovieList();

    MovieList(const MovieList &aList);

    ~MovieList();

    bool isEmpty() const;

    int getLength() const;

    bool retrieve(int index, long &movieID, int &audienceRadius) const;

    bool insert(int index, long movieID, int audienceRadius);

    bool remove(int index);

    bool find(const long movieID, const int audienceRadius);

    string getTime(long movieID) const;

private:
    struct MovieNode {
        int audienceRadius;
        long movieID;
        MovieNode *next;
    };
    int size;
    MovieNode *head;

    MovieNode *find(int index) const;
    // ...
    //you may define additional member functions and data members, if necessary
};


#endif //CS201HW3_MOVIELIST_H

/*
 * @author Efe Kerem Kesgin 21902857
 * @date 03.05.2021.
 */

#ifndef CS201_HW1_MOVIEBOOKINGSYSTEM_H
#define CS201_HW1_MOVIEBOOKINGSYSTEM_H

//#include "Reservation.h"
//#include "Movie.h"
#include "ReservationList.h"
#include "MovieList.h"

class MovieBookingSystem {
public :
    const static int numOfRow = 30;
    const static int numOfColumn = 26;

    MovieBookingSystem();

    ~MovieBookingSystem();

    void addMovie(const long movieID, const int audienceRadius);

    void cancelMovie(const long movieID);

    void showAllMovies() const;

    void showMovie(const long movieID) const;

    int makeReservation(const long movieID, const int row, const char col);

    void cancelReservations(ReservationList resCode);

    void showReservation(const int resCode) const;

private :
    ReservationList reservationCodes;
    MovieList movies;
    int reservationCounter;
    int reservationNumber;
};

#endif //CS201_HW1_MOVIEBOOKINGSYSTEM_H

/*
 * @author Efe Kerem Kesgin 21902857
 * @date 03.05.2021.
 */
#include <iostream>
#include "ReservationList.h"

using namespace std;

ReservationList::ReservationList() : size(0), head(NULL) {
}

ReservationList::~ReservationList() {
    while (!isEmpty())
        remove(1);
}

ReservationList::ReservationList(const ReservationList &aList) : size(aList.size) {
    if (aList.head == NULL)
        head = NULL;
    else {
        head = new ReservationNode;
        head->resItem = aList.head->resItem;
        head->rCode = aList.head->rCode;
        // copy rest of list
        ReservationNode *newPtr = head;  // new list ptr
        for (ReservationNode *origPtr = aList.head->next;
             origPtr != NULL;
             origPtr = origPtr->next) {
            newPtr->next = new ReservationNode;
            newPtr = newPtr->next;
            newPtr->resItem = origPtr->resItem;
            newPtr->rCode = origPtr->rCode;
        }
        newPtr->next = NULL;
    }
}

bool ReservationList::isEmpty() const {
    return size == 0;
}

int ReservationList::getLength() const {
    return size;
}

bool ReservationList::retrieve(int index, int &resItemCode) const {
    if (index < 1 || index > getLength()) {
        return false;
    }
    ReservationNode *cur = find(index);
    resItemCode = cur->rCode;
    return true;
}

bool ReservationList::retrieve(int index, Reservation &reservationItem) const {
    if (index < 1 || index > getLength()) {
        return false;
    }
    ReservationNode *cur = find(index);
    reservationItem = cur->resItem;
    return true;
}

bool ReservationList::remove(int index) {

    ReservationNode *cur;
    if (index == 0) index++;

    if ((index < 1) || (index > getLength()))
        return false;
    --size;

    if (index == 1) {
        cur = head;
        head = head->next;
    } else {
        ReservationNode *prev = find(index - 1);
        cur = prev->next;
        prev->next = cur->next;
    }
    cur->next = NULL;
    delete cur;
    cur = NULL;
    return true;
}

bool ReservationList::insert(int index, Reservation newResItem, int resCode) {
    int newLength = getLength() + 1;
    if (index < 1 || index > newLength) {
        return false;
    }
    ReservationNode *newPtr = new ReservationNode;
    size = newLength;
    newPtr->resItem = newResItem;
    newPtr->rCode = resCode;
    if (index == 1) {
        newPtr->next = head;
        head = newPtr;
    } else {
        ReservationNode *prev = find(index - 1);
        newPtr->next = prev->next;
        prev->next = newPtr;
    }
    return true;
}

bool ReservationList::insert(int index, int resCode) {
    int newLength = getLength() + 1;
    int newIndex = index + 1;

    index = newIndex;
    if (index < 1 || index > newLength) {
        return false;
    }
    ReservationNode *newPtr = new ReservationNode;
    size = newLength;
    newPtr->rCode = resCode;
    if (index == 1) {
        newPtr->next = head;
        head = newPtr;
    } else {
        ReservationNode *prev = find(index - 1);
        newPtr->next = prev->next;
        prev->next = newPtr;
    }
}

ReservationList::ReservationNode *ReservationList::find(int index) const {
    if (index < 1 || index > getLength()) {
        return NULL;
    } else { // count from the beginning of the list
        ReservationNode *cur = head;
        for (int skip = 1; skip < index; ++skip)
            cur = cur->next;
        return cur;
    }
}

/*
 * @author Efe Kerem Kesgin 21902857
 * @date 03.05.2021.
 */
#ifndef CS201_HW1_RESERVATIONLIST_H
#define CS201_HW1_RESERVATIONLIST_H

#include "Reservation.h"

class ReservationList {
public:
    ReservationList();

    ReservationList(const ReservationList &aList);

    ~ReservationList();

    bool isEmpty() const;

    int getLength() const;

    bool retrieve(int index, int &resCode) const;

    bool retrieve(int index, Reservation &reservation) const;

    bool insert(int index, Reservation reservation, int resCode);

    bool insert(int index, int resCode);

    bool remove(int index);

private:
    struct ReservationNode {
        Reservation resItem;
        int rCode;
        ReservationNode *next;
    };
    int size;
    ReservationNode *head;

    ReservationNode *find(int index) const;
    // ...
    //you may define additional member functions and data members, if necessary

};

#endif //CS201_HW1_RESERVATIONLIST_H
